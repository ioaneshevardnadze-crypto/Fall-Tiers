# Fall Tiers Discord Bot

Starter Discord bot for Minecraft PvP Tier Testing. It includes an application panel,
review buttons for authorized testers, a results announcement, and an optional
server-to-server website webhook.

## 1. Create the Discord application and bot

1. Open https://discord.com/developers/applications and choose **New Application**.
2. Name it `Fall Tiers`.
3. Open **Bot** and choose **Reset Token** / **Copy Token**. Keep it private.
4. Under **Installation** (or OAuth2 URL Generator), enable `bot` and `applications.commands`.
5. Grant only the needed permissions: View Channels, Send Messages, Embed Links, Read Message History.
6. Use the generated install link to add it to your Discord server.
7. Do not enable Administrator unless you have a specific reason.

## 2. Configure channels and role

In Discord Settings, enable User Settings > Advanced > Developer Mode.
Right-click your server, tester role, and channels and choose **Copy ID**.
Create:
- a private staff/review channel for applications;
- a public results channel for tier announcements;
- a role for trusted testers.

Copy `.env.example` to `.env` and fill in IDs and the bot token.

## 3. Run locally

Install Python 3.11 or newer, then in this folder run:

```bash
python -m venv .venv
```

Windows:
```powershell
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python bot.py
```

Edit `.env` with your real values first. Keep the computer and bot process running
for the bot to stay online. For 24/7 availability, deploy to a trusted host and set
the same environment variables in its secret settings.

## 4. First use

Players can run `/verify` and enter only their Minecraft IGN and region (for example EU, NA, AS). Their Discord account is linked automatically. This records the IGN they type; it does not independently prove Minecraft account ownership.

Run `/setup_tier_testing` as a server administrator in the channel where you want
the application panel to appear. Applicants click the button and fill out the modal.
Applications are posted to the configured review channel. A tester can set a tier
or deny the application. Results are announced in the configured announcement channel.

## 5. Website integration (not yet active by default)

The bot's optional webhook sends a JSON POST only when `WEBSITE_WEBHOOK_URL` is set.
Your Lovable website/backend must implement and secure a matching endpoint before
this feature can update the real leaderboard. Do not paste a bot token or webhook
secret into frontend/browser code. The current website URL alone is not an API endpoint.
Ask Lovable to inspect its existing database and implement a protected server-side
endpoint that validates the shared secret, verifies the payload, and updates the
same database used by the leaderboard. Then set the endpoint URL and secret in the
bot host's environment variables.

## Important limitations

- This starter stores applications in a local JSON file. Use persistent database storage
  for production hosting or multiple instances; local files may be lost on some hosts.
- The bot cannot prove that a Minecraft IGN belongs to a Discord user just because they
  type it. Add a verification method (for example, a one-time code verified in-game)
  if ownership verification is required.
- Testers can publish results only if they have the configured tester role or server
  Administrator permission.
- Never share your Discord bot token with anyone, including in chat.
